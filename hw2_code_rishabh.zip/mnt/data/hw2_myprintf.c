#include <stdio.h>
#include <stdarg.h>
#include <string.h>

int myprintf(const char *format, ...) {
    va_list args;
    va_start(args, format);

    int total_chars = 0;
    const char *p = format;

    // First, print the user message like printf does
    while (*p) {
        if (*p == '%') {
            p++;
            if (*p == 'c') {
                char ch = va_arg(args, int);
                total_chars += printf("%c", ch);
            } else if (*p == 'd') {
                int num = va_arg(args, int);
                total_chars += printf("%d", num);
            } else if (*p == 's') {
                char *str = va_arg(args, char *);
                total_chars += printf("%s", str);
            } else if (*p == '5' && *(p+1) == 'd') {
                p++;
                int num = va_arg(args, int);
                total_chars += printf("%05d", num); // Zero-padded integer
            } else {
                printf("Error: Unsupported format specifier\n");
                return -1;
            }
        } else {
            putchar(*p);
            total_chars++;
        }
        p++;
    }

    printf("\nArgument list:\n");
    // Print the list of user arguments
    p = format;
    va_start(args, format);  // Reinitialize the argument list
    while (*p) {
        if (*p == '%') {
            p++;
            if (*p == 'c') {
                char ch = va_arg(args, int);
                printf("Char --> %c\n", ch);
            } else if (*p == 'd') {
                int num = va_arg(args, int);
                printf("Integer --> %d\n", num);
            } else if (*p == 's') {
                char *str = va_arg(args, char *);
                printf("String --> %s\n", str);
            } else if (*p == '5' && *(p+1) == 'd') {
                p++;
                int num = va_arg(args, int);
                printf("Integer --> %05d\n", num);
            }
        }
        p++;
    }

    va_end(args);
    return total_chars;
}

int main() {
    // Example usage
    myprintf("This is CS%c%5d%s", '-', 551, " Systems Programming.\n");
    return 0;
}
