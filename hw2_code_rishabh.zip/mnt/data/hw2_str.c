#include <stdio.h>
#include <string.h>
#include <ctype.h>

int is_vowel(char ch) {
    ch = tolower(ch);
    return (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u');
}

int str_interleave(char *str1, char *str2, char *substr) {
    if (!str1 || !str2 || !substr) {
        printf("Error: Null input arguments\n");
        return -1;
    }
    
    printf("str1 %s\n", str1);
    printf("str2 %s\n", str2);

    // Calculate length of new string
    int len1 = strlen(str1);
    int len2 = strlen(str2);
    int max_len = len1 + len2;
    char newstr[max_len + 1];
    int idx = 0;

    // Interleave the characters
    for (int i = 0; i < len1 || i < len2; i++) {
        if (i < len1) {
            newstr[idx++] = is_vowel(str1[i]) ? toupper(str1[i]) : tolower(str1[i]);
        }
        if (i < len2) {
            newstr[idx++] = is_vowel(str2[i]) ? toupper(str2[i]) : tolower(str2[i]);
        }
    }
    newstr[idx] = '\0';

    // Print new string
    printf("newstr %s\n", newstr);

    // Print substr
    printf("substr %s\n", substr);

    // Count occurrences of substr (case-insensitive)
    int count = 0;
    for (int i = 0; i <= strlen(newstr) - strlen(substr); i++) {
        if (strncasecmp(&newstr[i], substr, strlen(substr)) == 0) {
            count++;
        }
    }

    // Print occurrences
    printf("occurrences %d\n", count);
    
    return 0;
}

int main() {
    // Example usage
    str_interleave("Hello", "World", "eO");
    return 0;
}
