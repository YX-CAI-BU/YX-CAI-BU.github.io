#ifndef HW2_H
#define HW2_H

#define printf myprintf

#endif
